var s1

function setup() 
{
  createCanvas(400, 400);
  s1 = new Student("john",12,6);
  s1.display()

}
function draw() 
{
  background(51);
 
}


